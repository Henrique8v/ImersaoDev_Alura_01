valorWons = prompt("Favor, digite um valor em Woms:")
// alert ("valorWons")
umwon = 0.0040
alert(valorWons * umwon)

